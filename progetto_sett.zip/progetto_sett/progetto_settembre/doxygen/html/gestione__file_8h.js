var gestione__file_8h =
[
    [ "apri_file", "gestione__file_8h.html#a4521d84a7b894dd83beadcc858ecaff1", null ],
    [ "carica_coda_da_file", "gestione__file_8h.html#a12f909a46e7daf3633431f2185cbdbbc", null ],
    [ "chiudi_file", "gestione__file_8h.html#af72ceef56638e57f867ce52af6723f92", null ],
    [ "salva_coda_su_file", "gestione__file_8h.html#a25bb99c0142ffdf60edfb60b12a854c2", null ]
];