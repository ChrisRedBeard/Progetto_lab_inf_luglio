var files_dup =
[
    [ "controlli.h", "controlli_8h.html", "controlli_8h" ],
    [ "dati.h", "dati_8h.html", "dati_8h" ],
    [ "funzioni.h", "funzioni_8h.html", "funzioni_8h" ],
    [ "gestione_file.h", "gestione__file_8h.html", "gestione__file_8h" ]
];