var funzioni_8h =
[
    [ "int_pos", "funzioni_8h.html#a9922fd2dffc5d6edd4ce2113bec6e70f", null ],
    [ "confronta_id", "funzioni_8h.html#a58714b298d807dc6e6a5d305c131511f", null ],
    [ "confronta_spedizioni", "funzioni_8h.html#a93397767d5984ccdc47ebbe7688ece86", null ],
    [ "input_float", "funzioni_8h.html#ae48c45bfbc8c220975763f53646e8206", null ],
    [ "input_id", "funzioni_8h.html#ac34b553fc580f4ab3d5f2244d2467956", null ],
    [ "input_string", "funzioni_8h.html#a47b5f254fd079d762cec5fee56e49f7e", null ],
    [ "ordinaCodaSpedizioni", "funzioni_8h.html#a38a25720f981db049bfa859f77fb0f25", null ],
    [ "rimuovi_doppioni_coda", "funzioni_8h.html#ab1ee99b757ee355481898a9b4425ba51", null ],
    [ "stampa_coda_spedizioni", "funzioni_8h.html#a7a57cedb42ffa8f847c59f0d133b7fa8", null ],
    [ "stampa_spedizione", "funzioni_8h.html#acd51b23e0bf575e3d5529f3c853bea5e", null ],
    [ "stampa_uscita", "funzioni_8h.html#abf3a84023ed0fa016845d9e05c51e593", null ]
];