var controlli_8h =
[
    [ "check_email_format", "controlli_8h.html#ad9e712f81004efdf6b648907f991bcaf", null ],
    [ "check_Id", "controlli_8h.html#ae22a48ed59ff5933ce953b309e9858b6", null ],
    [ "check_phone_format", "controlli_8h.html#a0c837a0216183b41f7cd7d3a6631bb2b", null ],
    [ "check_provincia", "controlli_8h.html#af522cab9245be4b4e88b14c52712c1af", null ],
    [ "controllo_date", "controlli_8h.html#a9cf671c797483546b6866c8fb0d465ec", null ]
];