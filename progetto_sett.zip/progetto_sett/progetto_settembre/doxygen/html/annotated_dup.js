var annotated_dup =
[
    [ "_coda_spedizione", "struct__coda__spedizione.html", null ],
    [ "_nodo_spedizione", "struct__nodo__spedizione.html", null ],
    [ "_pacco", "struct__pacco.html", null ],
    [ "_persona", "struct__persona.html", null ],
    [ "_spedizione", "struct__spedizione.html", null ]
];