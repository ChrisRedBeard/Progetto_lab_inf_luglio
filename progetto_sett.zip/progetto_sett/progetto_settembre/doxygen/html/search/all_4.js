var searchData=
[
  ['elimina_5fspedizione_0',['elimina_spedizione',['../dati_8h.html#a75609db0d71497985e9246a4ba815685',1,'dati.c']]],
  ['enqueue_1',['enqueue',['../dati_8h.html#a3ff6e7a642f0c98bd0ebbafcaf39e8d0',1,'dati.c']]]
];
