var searchData=
[
  ['carica_5fcoda_5fda_5ffile_0',['carica_coda_da_file',['../gestione__file_8h.html#a12f909a46e7daf3633431f2185cbdbbc',1,'gestione_file.c']]],
  ['check_5femail_5fformat_1',['check_email_format',['../controlli_8h.html#ad9e712f81004efdf6b648907f991bcaf',1,'controlli.c']]],
  ['check_5fid_2',['check_Id',['../controlli_8h.html#ae22a48ed59ff5933ce953b309e9858b6',1,'controlli.c']]],
  ['check_5fphone_5fformat_3',['check_phone_format',['../controlli_8h.html#a0c837a0216183b41f7cd7d3a6631bb2b',1,'controlli.c']]],
  ['check_5fprovincia_4',['check_provincia',['../controlli_8h.html#af522cab9245be4b4e88b14c52712c1af',1,'controlli.c']]],
  ['chiudi_5ffile_5',['chiudi_file',['../gestione__file_8h.html#af72ceef56638e57f867ce52af6723f92',1,'gestione_file.c']]],
  ['confronta_5fid_6',['confronta_id',['../funzioni_8h.html#a58714b298d807dc6e6a5d305c131511f',1,'funzioni.c']]],
  ['confronta_5fspedizioni_7',['confronta_spedizioni',['../funzioni_8h.html#a93397767d5984ccdc47ebbe7688ece86',1,'funzioni.c']]],
  ['controllo_5fdate_8',['controllo_date',['../controlli_8h.html#a9cf671c797483546b6866c8fb0d465ec',1,'controlli.c']]],
  ['creacoda_9',['creaCoda',['../dati_8h.html#acc956851313472bd53594661792564d3',1,'dati.c']]],
  ['creaspedizione_10',['creaSpedizione',['../dati_8h.html#aca2ecc268205591f9b302610e0d1a954',1,'dati.c']]]
];
