var searchData=
[
  ['modifica_5fspedizione_0',['modifica_spedizione',['../dati_8h.html#ab35668a38b1b171d6671b3182fbbc357',1,'dati.c']]]
];
