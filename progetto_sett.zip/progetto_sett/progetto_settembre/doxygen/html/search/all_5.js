var searchData=
[
  ['funzioni_2eh_0',['funzioni.h',['../funzioni_8h.html',1,'']]]
];
