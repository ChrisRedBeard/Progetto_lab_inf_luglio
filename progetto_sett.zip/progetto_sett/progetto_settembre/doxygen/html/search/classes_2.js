var searchData=
[
  ['pacco_0',['Pacco',['../struct_pacco.html',1,'']]],
  ['persona_1',['Persona',['../struct_persona.html',1,'']]]
];
