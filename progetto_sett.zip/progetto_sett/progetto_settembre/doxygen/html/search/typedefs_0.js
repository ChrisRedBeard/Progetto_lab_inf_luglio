var searchData=
[
  ['int_5fpos_0',['int_pos',['../funzioni_8h.html#a9922fd2dffc5d6edd4ce2113bec6e70f',1,'funzioni.h']]]
];
