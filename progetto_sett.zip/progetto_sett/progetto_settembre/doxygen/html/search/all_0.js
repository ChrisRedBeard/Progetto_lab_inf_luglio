var searchData=
[
  ['_5fcoda_5fspedizione_0',['_coda_spedizione',['../struct__coda__spedizione.html',1,'']]],
  ['_5fnodo_5fspedizione_1',['_nodo_spedizione',['../struct__nodo__spedizione.html',1,'']]],
  ['_5fpacco_2',['_pacco',['../struct__pacco.html',1,'']]],
  ['_5fpersona_3',['_persona',['../struct__persona.html',1,'']]],
  ['_5fspedizione_4',['_spedizione',['../struct__spedizione.html',1,'']]]
];
