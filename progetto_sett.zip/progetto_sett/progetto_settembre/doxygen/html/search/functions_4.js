var searchData=
[
  ['get_5fnumid_0',['get_numID',['../dati_8h.html#ad896245b7929892621b28577112e542f',1,'dati.c']]],
  ['getcap_1',['getCAP',['../dati_8h.html#a34073adedf710bd7a1f58647a4bc9fb9',1,'dati.c']]],
  ['getcitta_2',['getCitta',['../dati_8h.html#a42de29cdb1d1555e6f1e88726afadabe',1,'dati.c']]],
  ['getcognome_3',['getCognome',['../dati_8h.html#a06308bcbe1b84b01080ae974f9ba49e2',1,'dati.c']]],
  ['getdata_4',['getData',['../dati_8h.html#a369f6b64d1d9ec0706a4236d9c4c12b9',1,'dati.c']]],
  ['getmail_5',['getMail',['../dati_8h.html#a7b1a45699d3a304fed26666a5e0544b0',1,'dati.c']]],
  ['getnome_6',['getNome',['../dati_8h.html#a7fc3309a252fa973dbae8f435b3337f7',1,'dati.c']]],
  ['getpersona_7',['getPersona',['../dati_8h.html#a8c032db8e3e5bd8606e4319ab4a21544',1,'dati.c']]],
  ['getpeso_8',['getPeso',['../dati_8h.html#a58942f8d20100a9e5f466a5de269d666',1,'dati.c']]],
  ['getpriorita_9',['getPriorita',['../dati_8h.html#a46dd74f8103e68a74a21decefffda59b',1,'dati.c']]],
  ['getprov_10',['getProv',['../dati_8h.html#a7b532063fa8e4fe7ff3e79d21400783c',1,'dati.c']]],
  ['getstato_11',['getStato',['../dati_8h.html#abd9c4ccc6fb57deb046d7ecaf06d17d9',1,'dati.c']]],
  ['gettelefono_12',['getTelefono',['../dati_8h.html#accc94d9916fa253677ec5937d5400fd3',1,'dati.c']]],
  ['getvia_13',['getVia',['../dati_8h.html#a9b630ad9ac56fa7b06342c8d1b50587b',1,'dati.c']]],
  ['getvolume_14',['getVolume',['../dati_8h.html#ad121a947c146083aa4ba9d43d70763fe',1,'dati.c']]]
];
