var searchData=
[
  ['input_5ffloat_0',['input_float',['../funzioni_8h.html#ae48c45bfbc8c220975763f53646e8206',1,'funzioni.c']]],
  ['input_5fid_1',['input_id',['../funzioni_8h.html#ac34b553fc580f4ab3d5f2244d2467956',1,'funzioni.c']]],
  ['input_5fstring_2',['input_string',['../funzioni_8h.html#a47b5f254fd079d762cec5fee56e49f7e',1,'funzioni.c']]],
  ['inserimento_5fspedizione_3',['inserimento_spedizione',['../dati_8h.html#a67c35da769b3818be2b9ce5730efc2b2',1,'dati.c']]],
  ['int_5fpos_4',['int_pos',['../funzioni_8h.html#a9922fd2dffc5d6edd4ce2113bec6e70f',1,'funzioni.h']]],
  ['isempty_5',['isEmpty',['../dati_8h.html#a34d07b4d77d26d040ddee6af67233c13',1,'dati.c']]]
];
