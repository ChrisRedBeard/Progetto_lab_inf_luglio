var searchData=
[
  ['carica_5fcoda_5fda_5ffile_0',['carica_coda_da_file',['../gestione__file_8h.html#a12f909a46e7daf3633431f2185cbdbbc',1,'gestione_file.c']]],
  ['check_5femail_5fformat_1',['check_email_format',['../controlli_8h.html#ad9e712f81004efdf6b648907f991bcaf',1,'controlli.c']]],
  ['check_5fid_2',['check_Id',['../controlli_8h.html#ae22a48ed59ff5933ce953b309e9858b6',1,'controlli.c']]],
  ['check_5fphone_5fformat_3',['check_phone_format',['../controlli_8h.html#a0c837a0216183b41f7cd7d3a6631bb2b',1,'controlli.c']]],
  ['check_5fprovincia_4',['check_provincia',['../controlli_8h.html#af522cab9245be4b4e88b14c52712c1af',1,'controlli.c']]],
  ['chiudi_5ffile_5',['chiudi_file',['../gestione__file_8h.html#af72ceef56638e57f867ce52af6723f92',1,'gestione_file.c']]],
  ['codaspedizione_6',['CodaSpedizione',['../struct_coda_spedizione.html',1,'']]],
  ['confronta_5fid_7',['confronta_id',['../dati_8h.html#a3aafe12484cfe30b936c2fe18dbb5cdd',1,'dati.c']]],
  ['confronta_5fspedizioni_8',['confronta_spedizioni',['../dati_8h.html#a8c2538df7432eb1615708038cfc40afc',1,'dati.c']]],
  ['controlli_2eh_9',['controlli.h',['../controlli_8h.html',1,'']]],
  ['controllo_5fdate_10',['controllo_date',['../controlli_8h.html#a9cf671c797483546b6866c8fb0d465ec',1,'controlli.c']]],
  ['convalida_5fspedizioni_11',['convalida_spedizioni',['../dati_8h.html#a7edcf8f7e5a24908390fa24ed265681b',1,'dati.h']]]
];
