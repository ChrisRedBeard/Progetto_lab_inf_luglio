var searchData=
[
  ['dequeue_0',['dequeue',['../dati_8h.html#ade75e35667b2a198ed2a47acad45810c',1,'dati.c']]]
];
