var indexSectionsWithContent =
{
  0: "acdegimnopst",
  1: "cnps",
  2: "cdg",
  3: "acdegimost",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations"
};

