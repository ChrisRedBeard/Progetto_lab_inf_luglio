var searchData=
[
  ['dati_2eh_0',['dati.h',['../dati_8h.html',1,'']]]
];
