var annotated_dup =
[
    [ "CodaSpedizione", "struct_coda_spedizione.html", null ],
    [ "NodoSpedizione", "struct_nodo_spedizione.html", null ],
    [ "Pacco", "struct_pacco.html", null ],
    [ "Persona", "struct_persona.html", null ],
    [ "Spedizione", "struct_spedizione.html", null ]
];