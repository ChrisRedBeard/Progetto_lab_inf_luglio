var searchData=
[
  ['elimina_5fspedizione_0',['elimina_spedizione',['../dati_8h.html#a1bee01428de42b1c047748e57f4943da',1,'dati.c']]],
  ['enqueue_1',['enqueue',['../dati_8h.html#a4b40f7dd1d808357534a5e711e1452ab',1,'dati.c']]]
];
