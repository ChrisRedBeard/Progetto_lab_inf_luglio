var searchData=
[
  ['apri_5ffile_0',['apri_file',['../gestione__file_8h.html#a4521d84a7b894dd83beadcc858ecaff1',1,'gestione_file.c']]]
];
