var searchData=
[
  ['trim_5fleft_0',['trim_left',['../gestione__file_8h.html#ad315d3b7c7b1d64f6ec190a9069897ed',1,'gestione_file.c']]]
];
