var searchData=
[
  ['modifica_5fspedizione_0',['modifica_spedizione',['../dati_8h.html#a42c07508c53bae59de031853237fd441',1,'dati.c']]]
];
