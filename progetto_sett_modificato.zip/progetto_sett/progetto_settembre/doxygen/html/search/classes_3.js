var searchData=
[
  ['spedizione_0',['Spedizione',['../struct_spedizione.html',1,'']]]
];
