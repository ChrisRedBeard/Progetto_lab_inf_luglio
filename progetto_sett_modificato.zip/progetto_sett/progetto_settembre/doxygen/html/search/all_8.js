var searchData=
[
  ['ordinacodaspedizioni_0',['ordinaCodaSpedizioni',['../dati_8h.html#a38a25720f981db049bfa859f77fb0f25',1,'dati.c']]]
];
