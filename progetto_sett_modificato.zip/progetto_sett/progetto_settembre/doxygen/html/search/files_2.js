var searchData=
[
  ['gestione_5ffile_2eh_0',['gestione_file.h',['../gestione__file_8h.html',1,'']]]
];
