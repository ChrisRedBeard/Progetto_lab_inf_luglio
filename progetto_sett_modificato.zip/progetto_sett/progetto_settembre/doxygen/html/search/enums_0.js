var searchData=
[
  ['stati_0',['Stati',['../dati_8h.html#a6727f0c42516f2969c1788434b329338',1,'dati.h']]]
];
