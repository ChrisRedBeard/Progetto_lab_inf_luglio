var searchData=
[
  ['dati_2eh_0',['dati.h',['../dati_8h.html',1,'']]],
  ['dequeue_1',['dequeue',['../dati_8h.html#ade75e35667b2a198ed2a47acad45810c',1,'dati.c']]]
];
