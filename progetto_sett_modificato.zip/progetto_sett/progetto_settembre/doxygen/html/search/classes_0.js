var searchData=
[
  ['codaspedizione_0',['CodaSpedizione',['../struct_coda_spedizione.html',1,'']]]
];
