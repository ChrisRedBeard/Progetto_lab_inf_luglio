var searchData=
[
  ['initcoda_0',['initCoda',['../dati_8h.html#abe38a235816705c4fafa032ac1e35d10',1,'dati.c']]],
  ['initnodospedizione_1',['initNodoSpedizione',['../dati_8h.html#a8720f5dbda54348919a2f81d69c67f6b',1,'dati.c']]],
  ['initpacco_2',['initPacco',['../dati_8h.html#aba25fd59190a813d700b9f6e359abb1d',1,'dati.c']]],
  ['initpersona_3',['initPersona',['../dati_8h.html#aac1766433ebabda58c880cb333e6821e',1,'dati.c']]],
  ['initspedizione_4',['initSpedizione',['../dati_8h.html#aaf1889b47f437f60f2e35373bfcceb63',1,'dati.c']]],
  ['inserimento_5fpacco_5',['inserimento_pacco',['../dati_8h.html#a379c4b6d7b653a890512a422987d0f32',1,'dati.c']]],
  ['inserimento_5fpersona_6',['inserimento_Persona',['../dati_8h.html#af097e5012eaa4e0d69a991bb4515bc89',1,'dati.c']]],
  ['inserimento_5fspedizione_7',['inserimento_spedizione',['../dati_8h.html#a67c35da769b3818be2b9ce5730efc2b2',1,'dati.c']]],
  ['inserisciordinato_8',['inserisciOrdinato',['../dati_8h.html#ad8305a77c4799e89544ef36877980870',1,'dati.c']]],
  ['isempty_9',['isEmpty',['../dati_8h.html#a93f3b9431f4c0fd6bb216537ea3c063f',1,'dati.c']]]
];
